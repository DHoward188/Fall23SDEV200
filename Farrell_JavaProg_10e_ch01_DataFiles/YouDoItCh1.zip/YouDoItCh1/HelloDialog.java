// Filename HelloDialog.java 
// Written by Dylan Howard
// Written on 8/24/23
import javax.swing.JOptionPane; 
public class HelloDialog 
{
    public static void main(String[] args) 
    {
        JOptionPane.showMessageDialog(null, "Hello, world!"); 
    }     
}
