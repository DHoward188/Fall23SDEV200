package Chapter1;

public class MovieQuoteInfo {
    public static void main(String[] args)
    {
        System.out.println("My favorite movie quote is \"It's Goku, but Broly, call me Kakarot\"");
        System.out.println("The quote was from \"Dragon Ball Super: Broly\"");
        System.out.println("The quote was said by Goku");
        System.out.println("The movie was released in 2018");
    }
}
